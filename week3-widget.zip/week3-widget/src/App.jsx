import BMICalculator from './components/BMICalculator';

function App() {
  return (
    <div>
      <BMICalculator />
    </div>
  );
}

export default App;
